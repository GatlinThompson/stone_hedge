hardwareContainer = document.getElementById('hardware')

const createHardware = () => {

}

document.createElement('div')